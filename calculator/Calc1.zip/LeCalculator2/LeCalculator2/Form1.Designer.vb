﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.button27 = New System.Windows.Forms.Button()
        Me.button26 = New System.Windows.Forms.Button()
        Me.button25 = New System.Windows.Forms.Button()
        Me.button24 = New System.Windows.Forms.Button()
        Me.button23 = New System.Windows.Forms.Button()
        Me.button22 = New System.Windows.Forms.Button()
        Me.button21 = New System.Windows.Forms.Button()
        Me.button20 = New System.Windows.Forms.Button()
        Me.button19 = New System.Windows.Forms.Button()
        Me.button18 = New System.Windows.Forms.Button()
        Me.button17 = New System.Windows.Forms.Button()
        Me.button16 = New System.Windows.Forms.Button()
        Me.button15 = New System.Windows.Forms.Button()
        Me.button14 = New System.Windows.Forms.Button()
        Me.button13 = New System.Windows.Forms.Button()
        Me.button12 = New System.Windows.Forms.Button()
        Me.button11 = New System.Windows.Forms.Button()
        Me.button10 = New System.Windows.Forms.Button()
        Me.button9 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'textBox2
        '
        Me.textBox2.Enabled = False
        Me.textBox2.Location = New System.Drawing.Point(79, 126)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(75, 22)
        Me.textBox2.TabIndex = 57
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(79, 70)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(642, 22)
        Me.textBox1.TabIndex = 56
        '
        'button27
        '
        Me.button27.Location = New System.Drawing.Point(646, 302)
        Me.button27.Name = "button27"
        Me.button27.Size = New System.Drawing.Size(75, 23)
        Me.button27.TabIndex = 55
        Me.button27.Text = "1/x"
        Me.button27.UseVisualStyleBackColor = True
        '
        'button26
        '
        Me.button26.Location = New System.Drawing.Point(536, 125)
        Me.button26.Name = "button26"
        Me.button26.Size = New System.Drawing.Size(85, 23)
        Me.button26.TabIndex = 54
        Me.button26.Text = "CE"
        Me.button26.UseVisualStyleBackColor = True
        '
        'button25
        '
        Me.button25.Location = New System.Drawing.Point(228, 126)
        Me.button25.Name = "button25"
        Me.button25.Size = New System.Drawing.Size(269, 23)
        Me.button25.TabIndex = 53
        Me.button25.Text = "Retroceso"
        Me.button25.UseVisualStyleBackColor = True
        '
        'button24
        '
        Me.button24.Location = New System.Drawing.Point(79, 358)
        Me.button24.Name = "button24"
        Me.button24.Size = New System.Drawing.Size(75, 23)
        Me.button24.TabIndex = 52
        Me.button24.Text = "M+"
        Me.button24.UseVisualStyleBackColor = True
        '
        'button23
        '
        Me.button23.Location = New System.Drawing.Point(79, 302)
        Me.button23.Name = "button23"
        Me.button23.Size = New System.Drawing.Size(75, 23)
        Me.button23.TabIndex = 51
        Me.button23.Text = "MS"
        Me.button23.UseVisualStyleBackColor = True
        '
        'button22
        '
        Me.button22.Location = New System.Drawing.Point(79, 241)
        Me.button22.Name = "button22"
        Me.button22.Size = New System.Drawing.Size(75, 23)
        Me.button22.TabIndex = 50
        Me.button22.Text = "MR"
        Me.button22.UseVisualStyleBackColor = True
        '
        'button21
        '
        Me.button21.Location = New System.Drawing.Point(79, 190)
        Me.button21.Name = "button21"
        Me.button21.Size = New System.Drawing.Size(75, 23)
        Me.button21.TabIndex = 49
        Me.button21.Text = "MC"
        Me.button21.UseVisualStyleBackColor = True
        '
        'button20
        '
        Me.button20.Location = New System.Drawing.Point(227, 358)
        Me.button20.Name = "button20"
        Me.button20.Size = New System.Drawing.Size(75, 23)
        Me.button20.TabIndex = 48
        Me.button20.Text = "0"
        Me.button20.UseVisualStyleBackColor = True
        '
        'button19
        '
        Me.button19.Location = New System.Drawing.Point(227, 302)
        Me.button19.Name = "button19"
        Me.button19.Size = New System.Drawing.Size(75, 23)
        Me.button19.TabIndex = 47
        Me.button19.Text = "1"
        Me.button19.UseVisualStyleBackColor = True
        '
        'button18
        '
        Me.button18.Location = New System.Drawing.Point(227, 241)
        Me.button18.Name = "button18"
        Me.button18.Size = New System.Drawing.Size(75, 23)
        Me.button18.TabIndex = 46
        Me.button18.Text = "4"
        Me.button18.UseVisualStyleBackColor = True
        '
        'button17
        '
        Me.button17.Location = New System.Drawing.Point(227, 190)
        Me.button17.Name = "button17"
        Me.button17.Size = New System.Drawing.Size(75, 23)
        Me.button17.TabIndex = 45
        Me.button17.Text = "7"
        Me.button17.UseVisualStyleBackColor = True
        '
        'button16
        '
        Me.button16.Location = New System.Drawing.Point(335, 358)
        Me.button16.Name = "button16"
        Me.button16.Size = New System.Drawing.Size(75, 23)
        Me.button16.TabIndex = 44
        Me.button16.Text = "."
        Me.button16.UseVisualStyleBackColor = True
        '
        'button15
        '
        Me.button15.Location = New System.Drawing.Point(335, 302)
        Me.button15.Name = "button15"
        Me.button15.Size = New System.Drawing.Size(75, 23)
        Me.button15.TabIndex = 43
        Me.button15.Text = "2"
        Me.button15.UseVisualStyleBackColor = True
        '
        'button14
        '
        Me.button14.Location = New System.Drawing.Point(335, 241)
        Me.button14.Name = "button14"
        Me.button14.Size = New System.Drawing.Size(75, 23)
        Me.button14.TabIndex = 42
        Me.button14.Text = "5"
        Me.button14.UseVisualStyleBackColor = True
        '
        'button13
        '
        Me.button13.Location = New System.Drawing.Point(335, 190)
        Me.button13.Name = "button13"
        Me.button13.Size = New System.Drawing.Size(75, 23)
        Me.button13.TabIndex = 41
        Me.button13.Text = "8"
        Me.button13.UseVisualStyleBackColor = True
        '
        'button12
        '
        Me.button12.Location = New System.Drawing.Point(441, 358)
        Me.button12.Name = "button12"
        Me.button12.Size = New System.Drawing.Size(75, 23)
        Me.button12.TabIndex = 40
        Me.button12.Text = "+-"
        Me.button12.UseVisualStyleBackColor = True
        '
        'button11
        '
        Me.button11.Location = New System.Drawing.Point(441, 302)
        Me.button11.Name = "button11"
        Me.button11.Size = New System.Drawing.Size(75, 26)
        Me.button11.TabIndex = 39
        Me.button11.Text = "3"
        Me.button11.UseVisualStyleBackColor = True
        '
        'button10
        '
        Me.button10.Location = New System.Drawing.Point(441, 241)
        Me.button10.Name = "button10"
        Me.button10.Size = New System.Drawing.Size(75, 23)
        Me.button10.TabIndex = 38
        Me.button10.Text = "6"
        Me.button10.UseVisualStyleBackColor = True
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(441, 190)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(75, 23)
        Me.button9.TabIndex = 37
        Me.button9.Text = "9"
        Me.button9.UseVisualStyleBackColor = True
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(536, 358)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(75, 23)
        Me.button8.TabIndex = 36
        Me.button8.Text = "+"
        Me.button8.UseVisualStyleBackColor = True
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(536, 305)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(75, 23)
        Me.button7.TabIndex = 35
        Me.button7.Text = "-"
        Me.button7.UseVisualStyleBackColor = True
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(536, 246)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(75, 23)
        Me.button6.TabIndex = 34
        Me.button6.Text = "*"
        Me.button6.UseVisualStyleBackColor = True
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(536, 190)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(75, 23)
        Me.button5.TabIndex = 33
        Me.button5.Text = "/"
        Me.button5.UseVisualStyleBackColor = True
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(646, 358)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(75, 23)
        Me.button4.TabIndex = 32
        Me.button4.Text = "="
        Me.button4.UseVisualStyleBackColor = True
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(646, 246)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(75, 23)
        Me.button3.TabIndex = 31
        Me.button3.Text = "%"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(646, 190)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 30
        Me.button2.Text = "sqrt"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(646, 125)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 29
        Me.button1.Text = "C"
        Me.button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(730, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button27)
        Me.Controls.Add(Me.button26)
        Me.Controls.Add(Me.button25)
        Me.Controls.Add(Me.button24)
        Me.Controls.Add(Me.button23)
        Me.Controls.Add(Me.button22)
        Me.Controls.Add(Me.button21)
        Me.Controls.Add(Me.button20)
        Me.Controls.Add(Me.button19)
        Me.Controls.Add(Me.button18)
        Me.Controls.Add(Me.button17)
        Me.Controls.Add(Me.button16)
        Me.Controls.Add(Me.button15)
        Me.Controls.Add(Me.button14)
        Me.Controls.Add(Me.button13)
        Me.Controls.Add(Me.button12)
        Me.Controls.Add(Me.button11)
        Me.Controls.Add(Me.button10)
        Me.Controls.Add(Me.button9)
        Me.Controls.Add(Me.button8)
        Me.Controls.Add(Me.button7)
        Me.Controls.Add(Me.button6)
        Me.Controls.Add(Me.button5)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents textBox2 As TextBox
    Private WithEvents textBox1 As TextBox
    Private WithEvents button27 As Button
    Private WithEvents button26 As Button
    Private WithEvents button25 As Button
    Private WithEvents button24 As Button
    Private WithEvents button23 As Button
    Private WithEvents button22 As Button
    Private WithEvents button21 As Button
    Private WithEvents button20 As Button
    Private WithEvents button19 As Button
    Private WithEvents button18 As Button
    Private WithEvents button17 As Button
    Private WithEvents button16 As Button
    Private WithEvents button15 As Button
    Private WithEvents button14 As Button
    Private WithEvents button13 As Button
    Private WithEvents button12 As Button
    Private WithEvents button11 As Button
    Private WithEvents button10 As Button
    Private WithEvents button9 As Button
    Private WithEvents button8 As Button
    Private WithEvents button7 As Button
    Private WithEvents button6 As Button
    Private WithEvents button5 As Button
    Private WithEvents button4 As Button
    Private WithEvents button3 As Button
    Private WithEvents button2 As Button
    Private WithEvents button1 As Button
    Friend WithEvents Label1 As Label
End Class
